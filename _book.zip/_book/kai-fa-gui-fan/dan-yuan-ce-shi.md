* ### 单元测试目录，目录层次与业务代码层次基本相同

> ![](/assets/test01.png)

* ### service和mapper单元测试

> ### ![](/assets/unittest01.png)



