## 日常开发中常用到的报表及打印，大致为几下几种，根据实际需求进行选择使用。

* 统计报表及打印：一般是先查询列表，再打印，可使用ireport整合方式开发，详见”[ireport整合开发pdf报表](/kuang-jia-she-zhi/bao-biao-he-da-yin/ireportzheng-he-kai-fa-pdf-bao-biao.md)“。
* 统计图表：一般只是为了展示效果，但不需要打印，可使用echars报表整合开发。详见”[echars图表开发](/kuang-jia-she-zhi/bao-biao-he-da-yin/echarstu-biao-kai-fa.md)“
* 普通单页凭证打印：主要指网点柜面上的业务凭证打印，直接使用免费ScriptX.cab控件进行开发打印。详见"[单页凭证报表打印开发](/kuang-jia-she-zhi/bao-biao-he-da-yin/dan-ye-ping-zheng-bao-biao-da-yin-kai-fa.md)"



