springmvc的配置：

![](/assets/springmvc-config.png)

扫描带@controller 的java类。

![](/assets/springmvc-controller.png)

异常处理器：

![](/assets/springmvc-exception.png)

拦截器配置

![](/assets/springmvc-interceptor.png)

转换器配置（如日期转换器，把前端提交的字符串格式转换成日期格式。空字符串转换器，把空字符串移除）

![](/assets/springmvc-converters.png)

