CacheUtil

* * * #### getOperSes

      ```
      public static java.lang.Object getOperSes(java.lang.Object key)
      通过sessionId得到operId
      参数:
      key
      sessionId
      返回:
      ```

      通过sessionId得到operId  
      参数:  
      `key`

      * sessionId
        返回:
* #### removeOperSes

  ```
  public static void removeOperSes(java.lang.Object key)
  ```

  通过sessionId删除OperId  
  参数:  
  `key`

  * sessionId



