* 1.后台写法：controller方法名必须以add，update，save，update，del开头
![](/assets/repeat.png)
* 2.前台控制，前台通过button控制：
  ![](/assets/repeat1.png)
  button控件中加入check_resubmit属性值为true，并且必须有id属性