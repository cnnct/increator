

使用视频：[https://projectlombok.org/](https://projectlombok.org/)，包含安装、使用说明

下载地址：[https://projectlombok.org/](https://projectlombok.org/)

本项目中主要用到@Log4j注解来实现日志输出，但未使用@data注解。
