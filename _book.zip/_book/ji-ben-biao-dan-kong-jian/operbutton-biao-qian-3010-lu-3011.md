# oper\_button**标签**

#### oper\_button**标签的属性 :**

> oper\_button标签有6个属性
>
> **其中必填项加上了\*号，如下所示 :**
>
> > \***id ：** id属性
> >
> > **name ：** name属性
> >
> > \***value：** 显示名
> >
> > \***url：** 请求的url
> >
> > \***icon：** 按钮图标
> >
> > **size ：** size为尺寸标签,可以填的数值范围为（1-12）,如size="6",oper\_button标签的默认size为1

#### oper\_button标签的引入方式 :

```
<@oper_button id="oper_button" name="oper_button_name" size="3" icon="saved" value="提交" url="/tag/searchInput" onclick="test('a')" />
```

#### oper\_button标签显示效果图 :

![](/assets/oper_button.png)

