# **Form\_group标签**

#### **form\_group标签的属性：**

> > form\_group标签有1个属性为class；form\_group用于表单分组；form\_group标签的引入方式见form标签，
> >
> > 必须配合form标签使用



