# label**标签**

#### label**标签的属性 :**

> label标签有3个属性分别为为size、name、must\_star
>
> > **size ：** size为尺寸标签,可以填的数值范围为（1-12）,如size="6",label标签的默认size为1
> >
> > **name ：** name属性
> >
> > **must\_star ：** must\_star 属性为是否加必填标志“\*”，可以填写的值为“true”，“false”，默认为false

#### 



