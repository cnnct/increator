# **table\_toolbar标签**

#### **table\_toolbar标签的属性：**

> > table\_toolbar标签有1个属性为name；table\_toolbar配合table标签使用，在table标签前使用，
> >
> > 用于包裹操作表格的工具的工具栏
> >
> > 必须配合table标签使用

>> * table_toolbar属性:

>>   name: name属性

>>   size【1.2】: size属性，在【1.2】版本后加入size属性



