# download**标签**

#### download**标签的属性 :**

> download标签没有属性

#### download标签的引入方式 :

```
<@download/>
```

#### download标签使用方式 :

1.在需要异步下载的页面引入此标签

2.在js方法中调用下载方法

示例如下：

```
iframeDownloadFile(url);//此url为后台下载controller中方法的url
```



